from django.contrib.auth.models import AbstractUser
from django.db import models
from pygments.lexers import get_all_lexers
from pygments.styles import get_all_styles

LEXERS = [item for item in get_all_lexers() if item[1]]
LANGUAGE_CHOICES = sorted([(item[1][0], item[0]) for item in LEXERS])
STYLE_CHOICES = sorted((item, item) for item in get_all_styles())

class Member(AbstractUser): # 기존 user 모델 커스텀
    distinction = models.IntegerField(default=0)
    phoneNumber = models.CharField(max_length=20, default=0)
    name = models.CharField(max_length=10, default='')

class Class(models.Model):
    classNum = models.CharField(primary_key=True, max_length=20, default=0)
    className = models.CharField(max_length=20, default='')
    classYear = models.CharField(max_length=15, default='')
    username = models.IntegerField(default=0)
    profName = models.CharField(max_length=10, default='')
    day = models.CharField(max_length=100, default='')
    wifi = models.TextField()
    startTime = models.DateTimeField(auto_now=True) # 해당 레코드 갱신시 현재 시간 자동저장

class Subject(models.Model):
    username = models.IntegerField(default=0)
    classNum = models.CharField(max_length=20, default=0)
    className = models.CharField(max_length=20, default='')
    classYear = models.CharField(max_length=20, default=0)

class Check(models.Model):
    name = models.CharField(max_length=10, default='')
    classNum = models.CharField(max_length=20, default=0)
    created_date = models.DateTimeField(auto_now_add=True)
    username = models.IntegerField(default=0)
    attendCheck = models.IntegerField(default=3)

"""

rm -f tmp.db db.sqlite3
rm -r server/migrations
python manage.py makemigrations server
python manage.py migrate

python manage.py createsuperuser

토큰 발급
curl -X POST -H "Content-Type: application/json" -d '{"username":"2013111976","password":"1234"}' http://172.30.1.3:8000/api-token-auth/

토큰 갱신
curl -X POST -H "Content-Type: application/json" -d '{"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJleHAiOjE1MDcxNzEzNzAsImVtYWlsIjoiIiwidXNlcm5hbWUiOiIyMDEzMTExOTc2In0.AxAW1lvwvRs-ZS_zvHCtjuHedQdZFYaIIHYZKlGoPpo"}' http://127.0.0.1:8000/api-token-refresh/

토큰 확인
curl -X POST -H "Content-Type: application/json" -d '{"token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJleHAiOjE1MDcxNzEzNzAsImVtYWlsIjoiIiwidXNlcm5hbWUiOiIyMDEzMTExOTc2In0.AxAW1lvwvRs-ZS_zvHCtjuHedQdZFYaIIHYZKlGoPpo"}' http://127.0.0.1:8000/api-token-verify/

요청 보낼때
curl -H "Authorization: JWT eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJlbWFpbCI6IiIsInVzZXJfaWQiOjEsImV4cCI6MTUwNzE3MjA5NSwidXNlcm5hbWUiOiIyMDEzMTExOTc2In0.FOjuGfxmGuRhITzsziJzJorPD1mGzNdMacdgTcGRUS8" http://localhost:8000/Members/

서버 열 때
python manage.py runserver 192.168.0.8:8000
python manage.py runserver 10.80.21.248:8000
python manage.py runserver 192.168.1.121:8000
python manage.py runserver 172.30.1.3:8000
python manage.py runserver 10.80.29.209:8000
python manage.py runserver 10.70.4.104:8000
python manage.py runserver 10.70.1.212:8000
10.80.21.248


사용중인 포트 확인
lsof -i -P | grep -i "listen"

특정 포트번호를 사용하고 있는 프로세스 종료
kill $(lsof -t -i:8080)

홍진환 2013112056
이차헌 2013112060
"""