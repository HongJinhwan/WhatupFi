from rest_framework import serializers
from server.models import Member, Subject, Class, Check


class GetMemberSerializer(serializers.ModelSerializer):

    class Meta:
        model = Member
        fields = ('name', 'phoneNumber', 'distinction')


class MemberSerializer(serializers.ModelSerializer):
    def create(self, validated_data):                   # member를 생성하여 db에 저장하는 메소드

        member = Member.objects.create(
            username = validated_data['username'],
            distinction = validated_data['distinction'],
            phoneNumber = validated_data['phoneNumber'],
            name = validated_data['name'],
        )
        member.set_password(validated_data['password']) # REST framework JWT Auth을 사용하여 토큰을 생성할 때 set_password 메소드를 사용하여 저장해야 인식
        member.save()

        return member

    class Meta:
        model = Member
        fields = ('name', 'username', 'password', 'phoneNumber', 'distinction') # 관리자 페이지에서 보여줄 필드 설정


class SubjectSerializer(serializers.ModelSerializer):

    class Meta:
        model = Subject
        fields = ('username', 'classNum', 'className', 'classYear')


class ClassSerializer(serializers.ModelSerializer):

    class Meta:
        model = Class
        fields = ('classNum', 'className', 'classYear', 'username', 'profName', 'day', 'wifi', 'startTime')


class CheckSerializer(serializers.ModelSerializer):

    class Meta:
        model = Check
        fields = ('name', 'classNum', 'created_date', 'username', 'attendCheck')

