import re

from rest_framework import status, generics
from rest_framework.response import Response
from rest_framework.views import APIView

from server.models import Member, Subject, Class, Check
from server.serializers import MemberSerializer, SubjectSerializer, ClassSerializer, CheckSerializer

import datetime

minute = 5

# Member GET,POST
class MemberList(generics.ListCreateAPIView):
    queryset = Member.objects.all()
    serializer_class = MemberSerializer

# Member GET, PUT, DELETE
class MemberDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Member.objects.all()
    lookup_field = 'username'       # 객체 조회에 사용되는 필드를 변경
    serializer_class = MemberSerializer


# Subject GET,POST
class SubjectList(generics.ListCreateAPIView):
    queryset = Subject.objects.all()
    serializer_class = SubjectSerializer

# Subject GET, PUT, DELETE
class SubjectDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Subject.objects.all()
    lookup_field = 'classNum'
    serializer_class = SubjectSerializer


# Class GET,POST
class ClassList(generics.ListCreateAPIView):
    queryset = Class.objects.all()
    serializer_class = ClassSerializer

# Class GET, PUT, DELETE
class ClassDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Class.objects.all()
    lookup_field = 'classNum'
    serializer_class = ClassSerializer


# Check GET,POST
class CheckList(generics.ListCreateAPIView):

    queryset = Check.objects.all()
    serializer_class = CheckSerializer

# Check GET, PUT, DELETE
class CheckDetail(generics.RetrieveUpdateDestroyAPIView):

    queryset = Check.objects.all()
    lookup_field = 'classNum'
    serializer_class = CheckSerializer



"""
class MemberSubjects(APIView): - 요청한 사람의 subjects를 보여준다.

request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class MemberSubjects(APIView):

    def get(self, request, username, format=None):
        subjectList = Subject.objects.filter(username=username)  # Subject 목록들에서 username에 해당하는 것만 찾음

        if subjectList.count() != 0:
            serializer = SubjectSerializer(subjectList, many=True)  # many=True 사용하여 쿼리문까지 직렬화
            return Response(serializer.data)                        # 직렬화한 데이터를 넣어 응답
        else:                                                       # subject를 찾지 못하면
            return Response(status=status.HTTP_404_NOT_FOUND)


"""
class NowClass(APIView): - 학번을 받아 subject를 검색하고 현재 수업시간인 강의의 정보를 반환한다.

request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""

"""
class NowClass(APIView): - 학번을 받아 subject를 검색하고 현재 수업시간인 강의의 정보를 반환한다.

request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class NowClass(APIView):

    def get(self, request, username, format=None):

        dayPattern = re.compile(r'([가-힣])\S+[/](\S+)[:](\S+)[-](\S+)[:](\S+)') # 정규 표현식을 이용해 class의 요일과 시간을 나누기 위해 패턴지정

        dayTable = ['월', '화', '수', '목', '금', '토', '일']
        sysToday = dayTable[datetime.datetime.today().weekday()]                # 현재 서버의 요일

        nowSysTime = datetime.datetime.now()                                    # 현재 서버의 시간

        sysTime = (int(nowSysTime.hour) * 60 * 60) + (int(nowSysTime.minute) * 60)    # 현재 시스템 시간 (hour, minute)을 초로 바꿈

        try:
            subjectList = Subject.objects.filter(username=username)             # 요청한 member의 username과 일치하는 subject들을 찾음

            for i in range(0, subjectList.__len__()):                           # 찾은 subject의 개수만큼 반복
                nowClass = Class.objects.get(classNum=subjectList[i].classNum)  # 하나꺼내서 classNum의 값을 가져오고 그 값에 해당하는 class object를 찾음
                classDay = nowClass.day.split(',')                              # day의 값인 문자열을 ',' 기준으로 자름

                temp = dayPattern.search(classDay[0])                           # 첫 번째 문자열이 패턴을 거쳐 그룹화됨
                day1 = temp.group(1)                                            # 요일
                startTime1 = (int(temp.group(2)) * 60 * 60) + (int(temp.group(3)) * 60) # 시작 시간을 초로 바꿈
                endTime1 = (int(temp.group(4)) * 60 * 60) + (int(temp.group(5)) * 60)   # 종료 시간을 초로 바꿈

                if sysToday == day1 and sysTime >= startTime1 and sysTime <= endTime1:  # 요일이 같고 시작 시간과 끝나는 시간 범위 안에 있다면
                    serializer = ClassSerializer(nowClass)                              # 현재의 class를 직렬화
                    return Response(serializer.data)                                    # 직렬화한 값을 넣어 응답

                if classDay.__len__() == 2:
                    temp = dayPattern.search(classDay[1])                       # 세 번째 문자열이 패턴을 거쳐 그룹화됨
                    day2 = temp.group(1)
                    startTime2 = (int(temp.group(2)) * 60 * 60) + (int(temp.group(3)) * 60)
                    endTime2 = (int(temp.group(4)) * 60 * 60) + (int(temp.group(5)) * 60)

                    if sysToday == day2 and sysTime >= startTime2 and sysTime <= endTime2:
                        serializer = ClassSerializer(nowClass)
                        return Response(serializer.data)

                if classDay.__len__() == 3:
                    temp = dayPattern.search(classDay[2])                       # 세 번째 문자열이 패턴을 거쳐 그룹화됨
                    day3 = temp.group(1)
                    startTime3 = (int(temp.group(2)) * 60 * 60) + (int(temp.group(3)) * 60)
                    endTime3 = (int(temp.group(4)) * 60 * 60) + (int(temp.group(5)) * 60)

                    if sysToday == day3 and sysTime >= startTime3 and sysTime <= endTime3:
                        serializer = ClassSerializer(nowClass)
                        return Response(serializer.data)

        except Class.DoesNotExist:                                              # 요청한 member의 username과 일치하는 subject들을 못찾으면
            return Response(status=status.HTTP_404_NOT_FOUND)

"""
class NowClassStudent(APIView): - 학생이 현재 강의가 출석중인지 확인할 때 사용한다.(제한 시간 내에 해야함)

request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class NowClassStudent(APIView):

    def get(self, request, username, format=None):

        five_minute = datetime.datetime.now() - datetime.timedelta(minutes=minute)  # 5분

        try:
            nowClass = Class.objects.get(username=username, startTime__gt=five_minute)  # 교수님 학번, 5분 이내 출석체크 중인
            return Response(status=status.HTTP_200_OK)              # 응답보냄

        except Class.DoesNotExist:                                  # 위의 조건을 찾지 못했을 때
            return Response(status=status.HTTP_404_NOT_FOUND)       # 찾지 못했다고 알림



"""
class TimeLimitCheck(APIView): - 학생이 5분 이내에 출석을 했었으면 이미 했다고 알려주고 5분 이내에 출석을 하지 않았으면 출석 테이블을 수정한다.
1 = 출석, 2 = 지각, 3 = 결석
request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class TimeLimitCheck(APIView):

    def put(self, request, classNum, username, format=None):
        nowSysTime = datetime.datetime.now()                                    # 현재 서버의 시간
        try:
            startTime = Class.objects.get(classNum=classNum).startTime          # 출첵 시작 시간
            endTime = startTime + datetime.timedelta(minutes=minute)                 # 출첵 종료 시간 (5분 후)
            clientTime = nowSysTime - startTime                                 # 클라이언트에서 요청한 시간 - 출첵 시작 시간
            timeLimit = endTime - startTime                                     # 출첵 종료 시간 - 출첵 시작 시간
            five_minute = nowSysTime - datetime.timedelta(minutes=minute)            # 5분

            try:
                check = Check.objects.get(classNum=classNum, username=username, created_date__gt=five_minute)  # 강의 고유번호, 학생 학번, 출첵 시작한지 5분 이내의 오브젝트만 가져옴
                if timeLimit >= clientTime:                                     # 클라이언트가 요청보낸 시간이 제한시간보다 작거나 같을 때
                    if check.attendCheck == 1:                                  # 이미 출석 했으면
                        return Response(status=status.HTTP_207_MULTI_STATUS)
                    serializer = CheckSerializer(check, request.data)           # 리퀘스트의 내용으로 check를 수정하고 직렬화
                    if serializer.is_valid():                                   # 검증
                        serializer.save()                                       # 저장
                        return Response(status=status.HTTP_200_OK)
                    return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)# 검증에 실패했을 경우
                return Response(status=status.HTTP_423_LOCKED)  # 제한 시간을 초과했다고 알림

            except Check.DoesNotExist:
                print("=========== 3 ===========")
                return Response(status=status.HTTP_404_NOT_FOUND)               # 원하는 Check를 찾지 못했다고 알림
        except Class.DoesNotExist:
            print("=========== 4 ===========")
            return Response(status=status.HTTP_404_NOT_FOUND)                   # 원하는 Class를 찾지 못했다고 알림





"""
class SmartAttendance(APIView):
- check 테이블에 classNum, 5분 이내에 생성 조건에 맞는 것을 검색하고 존재하지 않으면 아직 출첵을 하지 않았다고보고 classNum, Subject에서 
  classNum와 관련된 학생들의 학번을 가져와 생성하여 check 테이블에 넣는다. 그리고 class 테이블에서 classNum으로 검색하여 wifi를 갱신시킨다.
- classNum, 5분 이내 생성 조건에 맞는 것이 존재하면 class 테이블에서 classNum으로 검색하여 wifi를 갱신시킨다.

request - 교수님의 wifi 정보
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class SmartAttendance(APIView):
    def put(self, request, classNum, format=None):
        five_minute = datetime.datetime.now() - datetime.timedelta(minutes=minute)  # 5분

        checkList = Check.objects.filter(classNum=classNum, created_date__gt=five_minute)  # 5분 이내에 생성된 Check들 가져옴

        print(checkList.count())
        if checkList.count() != 0:

            try:                                                                # 수동출석 후에 스마트 출석을 하는 경우
                classes = Class.objects.get(classNum=classNum)
                serializer = ClassSerializer(classes, request.data)
                if serializer.is_valid():
                    serializer.save()
                    return Response(status=status.HTTP_200_OK)
            except Class.DoesNotExist:
                return Response(status=status.HTTP_404_NOT_FOUND)

        else:                                                                   # classNum, 5분 이내 생성 조건을 만족하는 것을 찾지 못하면
            subjectList = Subject.objects.filter(classNum=classNum)
            print(subjectList.count())
            if subjectList.count() != 0:
                try:
                    for i in range(0, subjectList.count()):  # classNum을 수강하는 학생들의 수만큼 반복
                        username = subjectList[i].username
                        member = Member.objects.get(username=username).name
                        Check.objects.create(name=member, classNum=classNum, username=username)

                    classes = Class.objects.get(classNum=classNum)
                    serializer = ClassSerializer(classes, request.data)
                    if serializer.is_valid():
                        serializer.save()
                        return Response(status=status.HTTP_200_OK)
                except Class.DoesNotExist:
                    return Response(status=status.HTTP_404_NOT_FOUND)
                except Check.DoesNotExist:
                    return Response(status=status.HTTP_404_NOT_FOUND)

            else:
                return Response(status=status.HTTP_404_NOT_FOUND)



"""
class PassiveAttendance(APIView):
- classNum, 5분 이내 생성의 조건을 갖춘 Check가 있으면 직렬화하여 응답해준다.
- 조건에 맞는 것이 없으면 이 수업을 듣는 학생들을 subject에서 찾아 check 테이블에 저장시키고 명단을 응답해준다.

request - request의 내용이 담겨있다.
username - url에서 얻은 int형의 숫자들이다.
format=None - 여러가지 포맷으로 받을 수 있다.
"""
class PassiveAttendance(APIView):
    def get(self, request, classNum, format=None):

        five_minute = datetime.datetime.now() - datetime.timedelta(minutes=minute)  # 5분

        checkList = Check.objects.filter(classNum=classNum, created_date__gt=five_minute).order_by('name')  # 스마트 출석 후에 수동출석을 하는 경우

        if checkList.count() != 0:
            serializer = CheckSerializer(checkList, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

        else:
            subjectList = Subject.objects.filter(classNum=classNum)

            if subjectList.count() != 0:
                for i in range(0, subjectList.count()):                       # classNum을 수강하는 학생들의 수만큼 반복
                    username = subjectList[i].username
                    member = Member.objects.get(username=username).name
                    Check.objects.create(name=member, classNum=classNum, username=username) # check 테이블에 수강생들 생성해서 넣음
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)

            checkList = Check.objects.filter(classNum=classNum, created_date__gt=five_minute).order_by('name') # 생성한 check 테이블 내용을 검색해 응답보냄
            if checkList.count() != 0:
                serializer = CheckSerializer(checkList, many=True)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            else:
                return Response(status=status.HTTP_404_NOT_FOUND)

class PassiveCheck(APIView):
    def put(self, request, classNum, username, format=None):
        five_minute = datetime.datetime.now() - datetime.timedelta(minutes=minute)  # 5분
        try:
            check = Check.objects.get(classNum=classNum, username=username, created_date__gt=five_minute)
            serializer = CheckSerializer(check, request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(status=status.HTTP_200_OK)
        except Check.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        """
        
        token = request.META.get('HTTP_AUTHORIZATION')  # headers의 Authorization부분을 얻음
        token = token[4:]                               # JWT <- 를 잘라냄

        jwt_decode_handler = api_settings.JWT_DECODE_HANDLER                                # token의 내용을 decode해줄 handler 설정
        jwt_payload_get_username_handler = api_settings.JWT_PAYLOAD_GET_USERNAME_HANDLER    # token의 PAYLOAD 내용에서 username 가져올 handler 설정

        payload = jwt_decode_handler(token)                     # kandler를 거쳐 decode함
        user_name = jwt_payload_get_username_handler(payload)   # handler를 통해 username만 얻음
        """