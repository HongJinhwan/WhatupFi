from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework_jwt.views import obtain_jwt_token, refresh_jwt_token, verify_jwt_token
from django.conf.urls import url, include
from server import views

urlpatterns = [

    url(r'^Members/$', views.MemberList.as_view()),                         # 이용자 생성 및 전체 이용자 리스트 반환
    url(r'^Members/(?P<username>[0-9]+)/$', views.MemberDetail.as_view()),  # username에 해당하는 이용자 반환, 삭제, 수정

    url(r'^Subjects/$', views.SubjectList.as_view()),                                            # Subject 생성 및 전체 Subject 리스트 반환
    url(r'^Subjects/(?P<username>[0-9]+)/$', views.MemberSubjects.as_view()),                    # username에 해당하는 모든 Subject 반환
    url(r'^Subjects/(?P<username>[0-9]+)/(?P<classNum>[\S]+)/$', views.SubjectDetail.as_view()), # username과 classNum에 해당하는 Subject 반환, 삭제, 수정

    url(r'^Class/$', views.ClassList.as_view()),                                        # class 생성 및 전체 class 리스트 반환
    url(r'^Class/now/(?P<username>[0-9]+)/$', views.NowClass.as_view()),                # username에 해당되는 현재 시간의 class 반환
    url(r'^Class/now/student/(?P<username>[0-9]+)/$', views.NowClassStudent.as_view()), # username에 해당되는 현재 시간의 class 반환
    url(r'^Class/(?P<classNum>[\S]+)/$', views.ClassDetail.as_view()),                  # classNum에 해당하는 class 반환, 삭제, 수정

    url(r'^Check/$', views.CheckList.as_view()),                                        # 출석체크 생성 및 전체 출석체크 리스트 반환
    url(r'^Check/timeLimit/(?P<classNum>[\S]+)/(?P<username>[0-9]+)/$', views.TimeLimitCheck.as_view()),    # 해당하는 학생의 출석 수정
    url(r'^Check/(?P<classNum>[\S]+)/(?P<username>[0-9]+)/$', views.CheckDetail.as_view()), # classNum에 해당하는 출석체크 반환, 삭제, 수정
    url(r'^Check/smart/attendance/(?P<classNum>[\S]+)/$', views.SmartAttendance.as_view()),  #
    url(r'^Check/passive/attendance/(?P<classNum>[\S]+)/$', views.PassiveAttendance.as_view()),  # 현재 수업을 듣는 학생들 목록 가져옴

    url(r'^passive/check/(?P<classNum>[\S]+)/(?P<username>[0-9]+)/$', views.PassiveCheck.as_view()),

    url(r'^api-token-auth/', obtain_jwt_token),     # 인증에 성공하면 토큰 발급
    url(r'^api-token-refresh/', refresh_jwt_token), # 만료되지 않은 토큰 재발급
    url(r'^api-token-verify/', verify_jwt_token),   # 토큰 검증

]

# 탐색 가능한 API의 로그인 뷰와 로그아웃 뷰에 사용되는 url 패턴이다.
urlpatterns += [
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
]

urlpatterns = format_suffix_patterns(urlpatterns) #여러가지 포맷으로 받을 수 있다.
